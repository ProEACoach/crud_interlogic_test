<?PHP
include('db.php');
include('import.php');
include('header.php');

if(isset($_POST['search_box'])){
    $search_box = $_POST['search_box'];  
    echo("<h1>Resultados</h1>");
}
else{
    echo('No encontramos resultados');
}
?>


<div class="midle">
            <div class="col-md-8">
              <table class="table table-bordered table-dark" >
              <thead>
             
                  <th>Nombre</th>
                  <th>Edad</th>
                  <th>Activo</th>
                  <th>Acciones</th>
              
              </thead>
              
              <tbody>
                <?PHP 
    $query = ("SELECT * FROM users WHERE nombre LIKE '%$search_box%'" );
    $result = mysqli_query($connection, $query);
    $result_change = $result;

                while($row = mysqli_fetch_assoc($result_change)) { ?>
                  <tr>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['edad']; ?></td>
                    <td><?php $result = $row['activo']; 
                     echo boolean_validation($result);
                    ?></td>
                    <td>
                      <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary">
                     Editar </a>
                      <a href="delete.php?id=<?php echo $row['id']?>" class="btn btn-danger">
                      Eliminar
                      </a>
                    </td>
                  </tr>
                  <?php } ?>
                
              </tbody>
              
            </table>

            </div>

          </div>