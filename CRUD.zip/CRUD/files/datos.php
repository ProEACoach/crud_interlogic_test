<?PHP
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];


$datos[][] = [$nombre, $edad];

echo json_encode($datos);

?>