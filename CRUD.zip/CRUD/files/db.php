<?PHP 
session_start();
//Conexión a base de datos
$connection = mysqli_connect(
    'localhost',
    'root',
    '',
    'crud_usuarios_interlogic'
);
?>