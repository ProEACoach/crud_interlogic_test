<?PHP
include('db.php');
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "DELETE FROM users WHERE id = $id";
    $result = mysqli_query($connection, $query);
    if(!$result){
        die("No se puedo ejecutar tu petición");
    }

    $_SESSION['message'] ='Usuario eliminado' ;
    $_SESSION['message_type'] = 'alert-danger';
    header("Location: index.php");
}


include('footer.php');

?>