<?PHP
    include('db.php');
    include('header.php');
    include('import.php');
    $id = $_GET['id'];
        $query = "SELECT * FROM users WHERE id=$id";
        $result = mysqli_query($connection, $query);
        if (mysqli_num_rows($result) == 1){
           $row = mysqli_fetch_array($result);
           $nombre = $row['nombre'];
           $edad = $row['edad'];
           $activo = $row['activo'];
        }
        else{
            $output = 'Problema de conexión';
        }

    if (isset($_POST['update'])){
        $id = $_GET['id'];
        $nombre = $_POST['nombre'];
        $edad = $_POST['edad'];
        $activo = $_POST['inlineRadioOptions'];
        $activo = intval($activo);

        $query = "UPDATE users set nombre = '$nombre', edad = '$edad', activo = '$activo' WHERE id = '$id'";
        $result = mysqli_query($connection, $query);
        $_SESSION['message'] = 'Actualización exitosa';
        $_SESSION['message_type'] = 'alert-success';
        header("Location: index.php");
        
    }
?>

        <div class="midle">
        <div class="col-md-4">
          <div class="card text-bg-dark mb-3 row">
            <form action="edit.php?id=<?PHP echo($_GET['id'])?>" class="form" method="POST">
          
              <div class="form-group">
              <label for="nombre">Nombre (solo texto)</label>
                <input pattern="[a-zA-Z ]{2,254}" type="text" name="nombre" id="nombre" class="form-control" placeholder="Agrega el nuevo título " value="<?PHP echo $nombre;?>">
              </div>

              <div class="form-group">
              <label for="edad">Edad</label>
                <input  min="3" max="99" type="number" name="edad" id="edad" class="form-control" placeholder="Nueva edad en formato númerico (25, 35, 48...)" value="<?PHP echo$edad;?>">
              </div>



              <div class="form-check form-check-inline">
              <input required class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="1">
              <label class="form-check-label" for="inlineRadio1">Activo</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="2">
              <label class="form-check-label" for="inlineRadio2">Inactivo</label>
            </div>
              </div>


            <input type="submit" value="Actualizar información del usuario" class="btn btn-dark wt" name="update">
     <?PHP 
    include('footer.php');
    ?>