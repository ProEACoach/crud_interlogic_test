<nav class="navbar navbar-expand-lg bg-light sticky-top">
  <div class="container-fluid">
  <a href="https://www.interlogicglobal.com/" target="_blank">
    <img src="assets/logo_interlogic.png" alt="logo de la empresa Interlogic" class="logo_header">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
        </li>
     
      <form class="d-flex" role="search" method="POST" action="busqueda.php">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search_box" id="search_box">
        <button class="btn btn-dark" type="submit" id="search_button">Search</button>
      </form>
    </div>
  </div>
</nav>