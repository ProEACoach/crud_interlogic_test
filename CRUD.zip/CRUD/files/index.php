<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD de usuarios</title>
    <?PHP

use LDAP\Result;

    include('import.php'); //Importación de scripts y estilos
    ?>
  </head>
  <body>
    <?PHP
    include('header.php'); //Importamos el header para evitar redundancia y repetición de código
    ?>

    <main class="container"> <!--La etiqueta main identifica el contenido más relevante en HTML-->
        <h1 class="title color-wt">CRUD de Usuarios</h1> 
        <div >
          <div>

          <?PHP 
          if(isset($_SESSION['message']))
          {?>
            <div class="alert <?PHP echo($_SESSION['message_type']);?> alert-dismissible fade show" role="alert">
          
            <?PHP echo($_SESSION['message']); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div> 
         <?PHP  } session_unset();?>


            <div class="midle">
            <div class="col-md-4">
              <div class="card text-bg-dark mb-3 row">
                <form action="save_task.php" method="POST" class="form">
              
                  <div class="form-group">
                  <label for="nombre">Nombre (solo texto)</label>
                    <input pattern="[a-zA-Z ]{2,254}" type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre del usuario (Jose, Diego...)">
                  </div>

                  <div class="form-group">
                  <label for="edad">Edad</label>
                    <input  min="3" max="99" type="number" name="edad" id="edad" class="form-control" placeholder="Edad en formato númerico (25, 35, 48...)" id="edad">
                  </div>



                  <div class="form-check form-check-inline">
                  <input required class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                  <label class="form-check-label" for="inlineRadio1">Activo</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                  <label class="form-check-label" for="inlineRadio2">Inactivo</label>
                </div>
                  </div>


                <input type="submit" value="Agregar usuario" class="btn btn-dark wt" name="save_task" id="index_submit">

                  </div>

                </form>
              </div>
            </div>
            </div>

            <div class="midle">
            <div class="col-md-8">
              <table class="table table-bordered table-dark" >
              <thead>
             
                  <th>Nombre</th>
                  <th>Edad</th>
                  <th>Activo</th>
                  <th>Acciones</th>
              
              </thead>
              
              <tbody>
                <?PHP 
                $query = "SELECT * FROM users";
                $result_change = mysqli_query($connection, $query);

                while($row = mysqli_fetch_assoc($result_change)) { ?>
                  <tr>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['edad']; ?></td>
                    <td><?php $result = $row['activo']; 
                     echo boolean_validation($result);
                    ?></td>
                    <td>
                      <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary">
                     Editar </a>
                      <a href="delete.php?id=<?php echo $row['id']?>" class="btn btn-danger">
                      Eliminar
                      </a>
                    </td>
                  </tr>
                  <?php } ?>
                
              </tbody>
              
            </table>

            </div>

          </div>

        </div>
        </div>
    </main>
    <?PHP 
    include('footer.php');
    ?>
  </body>
</html>
