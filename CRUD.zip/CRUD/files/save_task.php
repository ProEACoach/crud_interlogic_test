<?PHP
include('db.php');
if(isset($_POST['save_task'])){
    $nombre = $_POST['nombre'];
    $edad = intval($_POST['edad']);
    $inlineRadioOptions = $_POST['inlineRadioOptions'];
    if($inlineRadioOptions=="option1"){
        $inlineRadioOptions=1;
    }
    else{
        $inlineRadioOptions=2;
    }

    echo($nombre.$edad.$inlineRadioOptions);
   echo(var_dump($inlineRadioOptions));

    $query = "INSERT INTO users (nombre, edad, activo) VALUES ('$nombre', '$edad', '$inlineRadioOptions');";
    $result = mysqli_query($connection, $query);

        if(!$result){
            $output="Eror de conexión";
        }
        else{
            $output="Usuario guardado";
        }
 

        $_SESSION['message'] = $output;
        $_SESSION['message_type'] = 'alert-success';
        header("Location: index.php");

}



include('footer.php');



?>