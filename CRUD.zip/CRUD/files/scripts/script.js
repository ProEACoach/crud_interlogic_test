//Conexión mediante Ajax y Jquery con JSON
$('#index_submit').click(resend);

function resend(){
    $.ajax({
        url:'datos.php',
        type:'POST',
        dataType:'json',
        data:{
            nombre: $('#nombre').val(),
            edad: $('#edad').val()
        }
        
    }).done(
        function(data){
            $('#salida').append(data[0][0]);
            $('#nombre').val('');
            $('#edad').val('');
        }
    );
   
 
}